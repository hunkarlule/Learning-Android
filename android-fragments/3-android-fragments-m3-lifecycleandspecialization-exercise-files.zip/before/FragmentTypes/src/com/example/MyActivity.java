package com.example;

import android.app.Activity;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class MyActivity extends Activity
{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater() ;
        inflater.inflate(R.menu.main_menu, menu) ;
        return true;
    }

    public void onMenuList(MenuItem item)
    {
        startActivity(new Intent(this, MyListActivity.class));
    }

    public void onMenuDialog(MenuItem item)
    {
    }

    public void onMenuDialogWrapped(MenuItem item)
    {
    }

    public void onMenuDialogAdd(MenuItem item)
    {
    }

    public void onMenuQuit(MenuItem item)
    {
        finish();
    }

}
