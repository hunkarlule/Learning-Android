package com.example;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by IntelliJ IDEA.
 * User: Jim
 * Date: 11/20/12
 * Time: 11:10 AM
 * To change this template use File | Settings | File Templates.
 */
public class MyListActivity extends Activity {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mylistactivity);
    }
}