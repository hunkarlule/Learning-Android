package com.example;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;

/**
 * Created by IntelliJ IDEA.
 * User: Jim
 * Date: 11/29/12
 * Time: 3:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class MyAlertDialogFragment extends DialogFragment implements DialogInterface.OnClickListener{

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setMessage("Do you wanna give it try");
        builder.setPositiveButton("Go for it", this);
        builder.setNegativeButton("Stay Safe", this);

        Dialog theDialog = builder.create();
        theDialog.setCanceledOnTouchOutside(false);

        return theDialog;
    }

    public void onClick(DialogInterface dialogInterface, int i) {
        switch(i) {
            case Dialog.BUTTON_POSITIVE:
                break;
            case Dialog.BUTTON_NEGATIVE:
                break;
        }
    }
}
