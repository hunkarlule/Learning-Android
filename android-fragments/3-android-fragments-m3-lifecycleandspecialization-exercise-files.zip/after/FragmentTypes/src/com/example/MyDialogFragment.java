package com.example;

import android.app.Dialog;
import android.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by IntelliJ IDEA.
 * User: Jim
 * Date: 11/29/12
 * Time: 1:24 PM
 * To change this template use File | Settings | File Templates.
 */
public class MyDialogFragment extends DialogFragment implements View.OnClickListener{

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View theView = inflater.inflate(R.layout.mydialogfragment, container, false);

        View yesButton = theView.findViewById(R.id.btnYes);
        yesButton.setOnClickListener(this);
        yesButton.requestFocus();

        View noButton = theView.findViewById(R.id.btnNo);
        noButton.setOnClickListener(this);

        Dialog theDialog = getDialog();
        if (theDialog != null) {
            theDialog.setTitle("This the Title");
            theDialog.setCanceledOnTouchOutside(false);
        }

        return theView;
    }

    public void onClick(View view) {
        int viewId = view.getId();
        switch(viewId) {
            case R.id.btnYes:
                break;
            case R.id.btnNo:
                break;
        }

        dismiss();
    }
}
