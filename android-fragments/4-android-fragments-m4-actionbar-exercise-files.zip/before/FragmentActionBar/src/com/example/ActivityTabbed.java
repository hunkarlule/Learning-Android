package com.example;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;

/**
 * Created by IntelliJ IDEA.
 * User: Jim
 * Date: 12/4/12
 * Time: 7:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class ActivityTabbed extends Activity{
    private final String _tab1DisplayName = "Whats new in Android 4.0";
    private final String _tab2DisplayName = "Android Intents";

    Fragment _tab1Fragment;
    Fragment _tab2Fragment;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    private void createTab(ActionBar actionBar, String displayName) {
        ActionBar.Tab newTab = actionBar.newTab();
        newTab.setText(displayName);
//        newTab.setTabListener(this);

        actionBar.addTab(newTab);
    }

}