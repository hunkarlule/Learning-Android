package com.example;

import android.R;
import android.app.*;
import android.os.Bundle;
import android.widget.ArrayAdapter;

/**
 * Created by IntelliJ IDEA.
 * User: Jim
 * Date: 12/4/12
 * Time: 7:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class ActivityListNavigation extends Activity {
    private final String _fragment0DisplayName = "Whats new in Android 4.0";
    private final String _fragment1DisplayName = "Android Intents";

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String[] listMembers = {_fragment0DisplayName, _fragment1DisplayName};

    }
}