package com.example;

/**
 * Created by IntelliJ IDEA.
 * User: Jim
 * Date: 11/14/12
 * Time: 4:16 PM
 * To change this template use File | Settings | File Templates.
 */
public interface CourseFragmentCoordinator {
    void onSelectedCourseChanged(int index);
}
